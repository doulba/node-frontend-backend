import {library} from '@fortawesome/fontawesome-svg-core';
import {faUser, faEyeSlash, faEye, faCheckCircle} from '@fortawesome/free-solid-svg-icons';

library.add(faUser, faEyeSlash, faEye, faCheckCircle);